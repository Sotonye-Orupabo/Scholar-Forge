"""Hybrid offline/online routing per blueprint section 1.3."""
from dataclasses import dataclass


@dataclass
class Route:
    target: str   # "local" or "cloud"
    label: str    # provenance label attached to the output


def route(tier: str, online: bool, prefer_local: bool = False) -> Route:
    if tier not in ("draft", "submission"):
        raise ValueError("tier must be 'draft' or 'submission'")
    if tier == "draft":
        return Route("local", "AI-DRAFT")  # draft work stays local regardless of connectivity
    if online and not prefer_local:
        return Route("cloud", "AI-DRAFT")
    return Route("local", "unreviewed, offline draft")
