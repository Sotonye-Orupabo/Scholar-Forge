"""Patchwriting, self-plagiarism and fact-retention checks."""
import re
from dataclasses import dataclass
from typing import Dict, List, Tuple


def _words(text: str) -> List[str]:
    return re.findall(r"\w+", text.lower())


def shared_runs(generated: str, source: str, n: int = 5) -> List[str]:
    """Maximal runs of >= n words shared verbatim, merged from overlapping n-grams."""
    g, s = _words(generated), _words(source)
    grams = {tuple(s[i:i + n]) for i in range(len(s) - n + 1)}
    runs, i = [], 0
    while i <= len(g) - n:
        if tuple(g[i:i + n]) in grams:
            j = i + n
            while j < len(g) and tuple(g[j - n + 1:j + 1]) in grams:
                j += 1
            runs.append(" ".join(g[i:j]))
            i = j
        else:
            i += 1
    return runs


def sentence_order_match(generated: str, source: str) -> float:
    """Fraction of generated sentences appearing in the same order as source sentences (fuzzy)."""
    def sents(t):
        return [" ".join(_words(x)) for x in re.split(r"(?<=[.!?])\s+", t) if len(_words(x)) > 3]
    g, s = sents(generated), sents(source)
    if not g or not s:
        return 0.0
    hits, pos = 0, 0
    for sent in g:
        gw = set(sent.split())
        for k in range(pos, len(s)):
            sw = set(s[k].split())
            if len(gw & sw) / max(len(gw | sw), 1) >= 0.7:
                hits, pos = hits + 1, k + 1
                break
    return hits / len(g)


@dataclass
class Finding:
    kind: str
    source: str
    detail: str


def patchwriting_check(generated: str, sources: Dict[str, str], n: int = 5,
                       order_threshold: float = 0.5) -> List[Finding]:
    out = []
    for name, text in sources.items():
        for run in shared_runs(generated, text, n):
            out.append(Finding("shared-run", name, f'"{run}"'))
        ratio = sentence_order_match(generated, text)
        if ratio >= order_threshold:
            out.append(Finding("sentence-order", name, f"{ratio:.0%} of sentences follow source order"))
    return out


def self_plagiarism_check(generated: str, prior_work: Dict[str, str], n: int = 5) -> List[Finding]:
    return [Finding("self-reuse", name, f'"{r}" (add a self-citation or rewrite)')
            for name, text in prior_work.items() for r in shared_runs(generated, text, n)]


def fact_retention(generated: str, source_chunks: List[str]) -> List[Finding]:
    """Numbers in generated prose must appear in at least one retrieved chunk."""
    corpus = " ".join(source_chunks)
    nums = re.findall(r"\b\d+(?:[.,]\d+)?%?", generated)
    return [Finding("unsupported-number", "retrieved chunks", n) for n in dict.fromkeys(nums)
            if n not in corpus and not re.fullmatch(r"(19|20)\d{2}", n)]
