"""Embedders. HashingEmbedder is a dependency-free stand-in for bge-small / nomic."""
import hashlib
import math
import re
from typing import List, Protocol


class Embedder(Protocol):
    dim: int

    def embed(self, text: str) -> List[float]: ...


class HashingEmbedder:
    """Signed feature hashing over word unigrams and bigrams (384-d like bge-small)."""

    def __init__(self, dim: int = 384):
        self.dim = dim

    def _features(self, text: str):
        words = re.findall(r"[a-z0-9]+", text.lower())
        yield from words
        yield from (f"{a}_{b}" for a, b in zip(words, words[1:]))

    def embed(self, text: str) -> List[float]:
        vec = [0.0] * self.dim
        for feat in self._features(text):
            h = int.from_bytes(hashlib.blake2b(feat.encode(), digest_size=8).digest(), "big")
            vec[h % self.dim] += 1.0 if (h >> 63) & 1 else -1.0
        norm = math.sqrt(sum(v * v for v in vec)) or 1.0
        return [v / norm for v in vec]


def cosine(a: List[float], b: List[float]) -> float:
    return sum(x * y for x, y in zip(a, b))
