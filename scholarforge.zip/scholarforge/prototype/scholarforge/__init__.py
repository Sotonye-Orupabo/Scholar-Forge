"""ScholarForge core prototype: ingest, hybrid search, citations, integrity, provenance."""
__version__ = "0.1.0"
