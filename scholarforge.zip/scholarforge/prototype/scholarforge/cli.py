"""python -m scholarforge.cli {ingest,search,check} ..."""
import argparse
import json
import sys

from .cite import load_csl, orphan_report
from .integrity import patchwriting_check
from .store import Store


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="scholarforge")
    p.add_argument("--db", default="scholarforge.db")
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("ingest"); a.add_argument("folder")
    s = sub.add_parser("search"); s.add_argument("query"); s.add_argument("-k", type=int, default=5)
    c = sub.add_parser("check"); c.add_argument("draft"); c.add_argument("--csl"); c.add_argument("--sources")
    args = p.parse_args(argv)
    store = Store(args.db)
    if args.cmd == "ingest":
        print(json.dumps(store.ingest_dir(args.folder), indent=2))
    elif args.cmd == "search":
        for r in store.search(args.query, args.k):
            print(f'[{r["csl_id"]}, p. {r["page"]}] ({r["section"]}) {r["text"][:160]}...')
    else:
        text = open(args.draft, encoding="utf-8").read()
        if args.csl:
            print(json.dumps(orphan_report(text, load_csl(args.csl)), indent=2))
        if args.sources:
            import os
            srcs = {n: open(os.path.join(args.sources, n), encoding="utf-8").read()
                    for n in os.listdir(args.sources)}
            for f in patchwriting_check(text, srcs):
                print(f"{f.kind}: {f.source}: {f.detail}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
