"""Structure-aware chunking: 300-500 word blocks keeping section header and page."""
import re
from dataclasses import dataclass
from typing import Iterator, List

HEADING = re.compile(r"^(#{1,6})\s+(.*\S)\s*$|^(\d+(?:\.\d+)*)\s+([A-Z].{2,80})$")


@dataclass
class Chunk:
    text: str
    section: str
    page: int
    ordinal: int


def _blocks(pages: List[str]) -> Iterator[tuple]:
    """Yield (kind, text, page). kind is 'h' for headings, 'p' for paragraphs."""
    for page_no, page in enumerate(pages, start=1):
        for para in re.split(r"\n\s*\n", page):
            para = para.strip()
            if not para:
                continue
            first = para.splitlines()[0]
            m = HEADING.match(first)
            if m and len(para.splitlines()) == 1:
                yield "h", (m.group(2) or m.group(4)).strip(), page_no
            else:
                yield "p", " ".join(para.split()), page_no


def chunk_pages(pages: List[str], min_words: int = 300, max_words: int = 500) -> List[Chunk]:
    chunks: List[Chunk] = []
    section, buf, buf_page, words = "Front matter", [], 1, 0

    def flush():
        nonlocal buf, words
        if buf:
            chunks.append(Chunk(" ".join(buf), section, buf_page, len(chunks)))
        buf, words = [], 0

    for kind, text, page in _blocks(pages):
        if kind == "h":
            if words >= min_words // 3:  # keep tiny sections attached to their neighbour
                flush()
            section = text
            continue
        n = len(text.split())
        if n > max_words:  # split oversized paragraphs on sentence boundaries
            for sent in re.split(r"(?<=[.!?])\s+", text):
                sn = len(sent.split())
                if words + sn > max_words:
                    flush()
                if not buf:
                    buf_page = page
                buf.append(sent)
                words += sn
            continue
        if words + n > max_words:
            flush()
        if not buf:
            buf_page = page
        buf.append(text)
        words += n
        if words >= min_words:
            flush()
    flush()
    return chunks
