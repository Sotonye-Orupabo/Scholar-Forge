"""AI interaction log and disclosure appendix generator."""
import difflib
import json
import sqlite3
import time
from typing import List, Optional


class ProvenanceLog:
    def __init__(self, db: Optional[sqlite3.Connection] = None):
        self.db = db or sqlite3.connect(":memory:")
        self.db.execute("""CREATE TABLE IF NOT EXISTS ai_events(
            id INTEGER PRIMARY KEY, ts REAL, model TEXT, tier TEXT, prompt TEXT,
            output TEXT, final_text TEXT, section TEXT)""")

    def record(self, model: str, tier: str, prompt: str, output: str, section: str,
               final_text: Optional[str] = None) -> int:
        cur = self.db.execute(
            "INSERT INTO ai_events(ts, model, tier, prompt, output, final_text, section) VALUES(?,?,?,?,?,?,?)",
            (time.time(), model, tier, prompt, output, final_text if final_text is not None else output, section))
        self.db.commit()
        return cur.lastrowid

    def human_edit_ratio(self, event_id: int) -> float:
        out, final = self.db.execute("SELECT output, final_text FROM ai_events WHERE id=?",
                                     (event_id,)).fetchone()
        return round(1 - difflib.SequenceMatcher(None, out.split(), final.split()).ratio(), 3)

    def events(self) -> List[tuple]:
        return self.db.execute("SELECT id, model, tier, section, prompt FROM ai_events ORDER BY id").fetchall()


PRESETS = {
    "generic": "I used generative AI tools in preparing this work. Details follow.",
    "oxford": "Declaration of generative AI use: the tools below were used as stated, and all "
              "submitted text was reviewed and edited by the author.",
    "usask": "Statement on the use of artificial intelligence: the author documents each AI-assisted "
             "step below and takes responsibility for the final text.",
}


def disclosure(log: ProvenanceLog, preset: str = "generic") -> str:
    lines = ["## AI Disclosure Statement", "", PRESETS[preset], "",
             "| # | Model | Section | Prompt intent | Human edit ratio |", "|---|---|---|---|---|"]
    for eid, model, tier, section, prompt in log.events():
        intent = " ".join(prompt.split())[:70]
        lines.append(f"| {eid} | {model} ({tier}) | {section} | {intent} | {log.human_edit_ratio(eid):.0%} |")
    return "\n".join(lines) + "\n"
