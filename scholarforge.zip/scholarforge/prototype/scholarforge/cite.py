"""Minimal CSL-JSON handling, style formatting and bidirectional orphan checks."""
import json
import re
from typing import Dict, List, Set, Tuple

Record = Dict[str, object]


def _authors(rec: Record) -> List[Dict[str, str]]:
    return list(rec.get("author", []))  # type: ignore[arg-type]


def _year(rec: Record) -> str:
    return str(rec["issued"]["date-parts"][0][0])  # type: ignore[index]


def _initials(given: str) -> str:
    return " ".join(p[0] + "." for p in re.split(r"[\s-]+", given) if p)


def in_text(rec: Record, page: str = "") -> str:
    """[Author, Year, p. X] form used by the drafting engine and verifier."""
    a = _authors(rec)
    name = a[0]["family"] if len(a) == 1 else f'{a[0]["family"]} et al.' if len(a) > 2 else \
        f'{a[0]["family"]} and {a[1]["family"]}'
    return f"[{name}, {_year(rec)}" + (f", p. {page}]" if page else "]")


def bibliography_entry(rec: Record, style: str = "apa") -> str:
    a = _authors(rec)
    title, container = rec.get("title", ""), rec.get("container-title", "")
    vol, pages, doi = rec.get("volume", ""), rec.get("page", ""), rec.get("DOI", "")
    if style == "apa":
        names = ", & ".join(f'{x["family"]}, {_initials(x["given"])}' for x in a) if len(a) > 1 else \
            f'{a[0]["family"]}, {_initials(a[0]["given"])}'
        tail = f" *{container}*" + (f", *{vol}*" if vol else "") + (f", {pages}" if pages else "")
        return f"{names} ({_year(rec)}). {title}.{tail if container else ''}." + \
            (f" https://doi.org/{doi}" if doi else "")
    if style == "harvard":
        names = " and ".join(f'{x["family"]}, {_initials(x["given"])}' for x in a)
        return f"{names} ({_year(rec)}) '{title}', *{container}*" + (f", {vol}" if vol else "") + \
            (f", pp. {pages}" if pages else "") + "."
    if style == "ieee":
        names = ", ".join(f'{_initials(x["given"])} {x["family"]}' for x in a)
        return f'{names}, "{title}," {container}' + (f", vol. {vol}" if vol else "") + \
            (f", pp. {pages}" if pages else "") + f", {_year(rec)}."
    raise ValueError(f"unsupported style: {style}")


def load_csl(path: str) -> Dict[str, Record]:
    with open(path, encoding="utf-8") as fh:
        return {r["id"]: r for r in json.load(fh)}


def orphan_report(text: str, bibliography: Dict[str, Record]) -> Dict[str, List[str]]:
    """Every in-text citation needs a record; every record must be cited at least once."""
    cited: Set[Tuple[str, str]] = set()
    for m in re.finditer(r"\[([A-Z][^\[\],\d]*?),\s*(\d{4})[a-z]?(?:,\s*pp?\.\s*[\d\u2013\-]+)?\]", text):
        cited.add((re.split(r"\s+(?:et al\.?|and)\s*", m.group(1))[0].split()[-1], m.group(2)))
    known = {(_authors(r)[0]["family"], _year(r)): rid for rid, r in bibliography.items()}
    return {
        "cited_without_entry": sorted(f"{a}, {y}" for a, y in cited - set(known)),
        "entry_never_cited": sorted(known[k] for k in set(known) - cited),
    }
