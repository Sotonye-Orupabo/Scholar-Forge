"""SQLite store: documents, chunks (with vectors), FTS5 keyword index."""
import hashlib
import json
import os
import re
import sqlite3
from typing import Dict, List, Optional

from .chunk import chunk_pages
from .embed import Embedder, HashingEmbedder, cosine

SCHEMA = """
CREATE TABLE IF NOT EXISTS docs(
  id INTEGER PRIMARY KEY, path TEXT UNIQUE, sha256 TEXT, title TEXT, csl_id TEXT);
CREATE TABLE IF NOT EXISTS chunks(
  id INTEGER PRIMARY KEY, doc_id INTEGER REFERENCES docs(id) ON DELETE CASCADE,
  ordinal INTEGER, section TEXT, page INTEGER, text TEXT, vec TEXT);
CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(text, content='chunks', content_rowid='id');
"""


def read_pages(path: str) -> List[str]:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError as e:
            raise RuntimeError("PDF ingestion needs `pip install pypdf`") from e
        return [(p.extract_text() or "") for p in PdfReader(path).pages]
    with open(path, encoding="utf-8", errors="ignore") as fh:
        return fh.read().split("\f")  # form feed marks a page break in text sources


class Store:
    def __init__(self, db_path: str = ":memory:", embedder: Optional[Embedder] = None):
        self.db = sqlite3.connect(db_path)
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.executescript(SCHEMA)
        self.embedder = embedder or HashingEmbedder()

    def ingest(self, path: str, csl_id: Optional[str] = None) -> str:
        """Returns 'added', 'updated' or 'unchanged' (hash check mirrors the sync daemon)."""
        with open(path, "rb") as fh:
            digest = hashlib.sha256(fh.read()).hexdigest()
        row = self.db.execute("SELECT id, sha256 FROM docs WHERE path=?", (path,)).fetchone()
        if row and row[1] == digest:
            return "unchanged"
        status = "updated" if row else "added"
        if row:
            self.db.execute("DELETE FROM chunks WHERE doc_id=?", (row[0],))
            self.db.execute("DELETE FROM docs WHERE id=?", (row[0],))
        title = os.path.splitext(os.path.basename(path))[0]
        cur = self.db.execute("INSERT INTO docs(path, sha256, title, csl_id) VALUES(?,?,?,?)",
                              (path, digest, title, csl_id or title))
        doc_id = cur.lastrowid
        for c in chunk_pages(read_pages(path)):
            cc = self.db.execute(
                "INSERT INTO chunks(doc_id, ordinal, section, page, text, vec) VALUES(?,?,?,?,?,?)",
                (doc_id, c.ordinal, c.section, c.page, c.text, json.dumps(self.embedder.embed(c.text))))
            self.db.execute("INSERT INTO chunks_fts(rowid, text) VALUES(?,?)", (cc.lastrowid, c.text))
        self.db.commit()
        return status

    def ingest_dir(self, folder: str) -> Dict[str, str]:
        out = {}
        for name in sorted(os.listdir(folder)):
            if name.lower().endswith((".pdf", ".txt", ".md")):
                out[name] = self.ingest(os.path.join(folder, name))
        return out

    def search(self, query: str, k: int = 5) -> List[dict]:
        """Hybrid retrieval: dense cosine + FTS5 BM25, fused with reciprocal rank fusion."""
        qv = self.embedder.embed(query)
        rows = self.db.execute(
            "SELECT c.id, c.text, c.section, c.page, d.csl_id, d.path, c.vec "
            "FROM chunks c JOIN docs d ON d.id=c.doc_id").fetchall()
        dense = sorted(rows, key=lambda r: -cosine(qv, json.loads(r[6])))
        terms = " OR ".join(re.findall(r"[A-Za-z0-9]{3,}", query))
        lexical = []
        if terms:
            lexical = [r[0] for r in self.db.execute(
                "SELECT rowid FROM chunks_fts WHERE chunks_fts MATCH ? ORDER BY rank LIMIT 50", (terms,))]
        score: Dict[int, float] = {}
        for rank, r in enumerate(dense[:50]):
            score[r[0]] = score.get(r[0], 0) + 1 / (60 + rank)
        for rank, cid in enumerate(lexical):
            score[cid] = score.get(cid, 0) + 1 / (60 + rank)
        by_id = {r[0]: r for r in rows}
        top = sorted(score, key=score.get, reverse=True)[:k]
        return [{"chunk_id": i, "text": by_id[i][1], "section": by_id[i][2], "page": by_id[i][3],
                 "csl_id": by_id[i][4], "path": by_id[i][5], "score": round(score[i], 5)} for i in top]
