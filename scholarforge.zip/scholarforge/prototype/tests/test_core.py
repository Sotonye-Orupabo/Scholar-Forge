import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from scholarforge.chunk import chunk_pages
from scholarforge.cite import bibliography_entry, in_text, orphan_report
from scholarforge.integrity import fact_retention, patchwriting_check, self_plagiarism_check, shared_runs
from scholarforge.provenance import ProvenanceLog, disclosure
from scholarforge.router import route
from scholarforge.store import Store
from tools import verify_output as vo

REC = {"id": "smith2020", "author": [{"family": "Smith", "given": "Jane Q"}],
       "issued": {"date-parts": [[2020]]}, "title": "Sleep and memory",
       "container-title": "Journal of Sleep", "volume": "12", "page": "10-25", "DOI": "10.1000/xyz"}

SOURCE = ("Sleep consolidates memory. " * 3 + "\n\n") * 1 + \
    "Participants who slept eight hours recalled 34% more items than those who stayed awake."


def write(path, text):
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


class Chunking(unittest.TestCase):
    def test_sizes_and_metadata(self):
        para = " ".join(["word"] * 120)
        pages = [f"# Methods\n\n{para}\n\n{para}\n\n{para}", f"{para}\n\n{para}\n\n{para}"]
        chunks = chunk_pages(pages)
        self.assertTrue(all(len(c.text.split()) <= 500 for c in chunks))
        self.assertEqual(chunks[0].section, "Methods")
        self.assertEqual(chunks[0].page, 1)
        self.assertEqual(chunks[-1].page, 2)


class Retrieval(unittest.TestCase):
    def test_hash_skip_and_search(self):
        with tempfile.TemporaryDirectory() as d:
            a = os.path.join(d, "sleep.txt")
            write(a, "# Results\n\nSleep improves memory consolidation in adults.\f"
                               "Page two discusses caffeine and alertness in shift workers.")
            b = os.path.join(d, "tax.txt")
            write(b, "Corporate tax rates changed across several jurisdictions last decade.")
            st = Store()
            self.assertEqual(st.ingest(a), "added")
            st.ingest(b)
            self.assertEqual(st.ingest(a), "unchanged")
            top = st.search("memory consolidation during sleep", k=1)[0]
            self.assertEqual(top["csl_id"], "sleep")
            self.assertEqual(top["page"], 1)


class Citations(unittest.TestCase):
    def test_formats_and_orphans(self):
        self.assertEqual(in_text(REC, "14"), "[Smith, 2020, p. 14]")
        self.assertIn("Smith, J. Q. (2020)", bibliography_entry(REC, "apa"))
        text = "Claim [Smith, 2020, p. 3]. Another [Jones, 2019, p. 1]."
        rep = orphan_report(text, {"smith2020": REC, "lee2018": {**REC, "id": "lee2018",
                                   "author": [{"family": "Lee", "given": "A"}],
                                   "issued": {"date-parts": [[2018]]}}})
        self.assertEqual(rep["cited_without_entry"], ["Jones, 2019"])
        self.assertEqual(rep["entry_never_cited"], ["lee2018"])


class Integrity(unittest.TestCase):
    def test_patchwriting_and_facts(self):
        copied = "Participants who slept eight hours recalled 34% more items than others."
        self.assertTrue(shared_runs(copied, SOURCE))
        self.assertTrue(patchwriting_check(copied, {"s": SOURCE}))
        fresh = "Rested volunteers remembered a larger share of the list."
        self.assertFalse(shared_runs(fresh, SOURCE))
        self.assertEqual([f.detail for f in fact_retention("Recall rose 41% overall.", [SOURCE])], ["41%"])
        self.assertTrue(self_plagiarism_check(copied, {"old_thesis.md": SOURCE}))


class Provenance(unittest.TestCase):
    def test_disclosure_and_router(self):
        log = ProvenanceLog()
        eid = log.record("local-llama3-8b", "draft", "Outline chapter 2", "one two three four", "2.1",
                         final_text="one two three five")
        self.assertGreater(log.human_edit_ratio(eid), 0)
        self.assertIn("| 1 | local-llama3-8b (draft)", disclosure(log, "oxford"))
        self.assertEqual(route("draft", online=True).target, "local")
        self.assertEqual(route("submission", online=True).target, "cloud")
        self.assertEqual(route("submission", online=False).label, "unreviewed, offline draft")


class Verifier(unittest.TestCase):
    GOOD = ("Sleep aids recall [Smith, 2020, p. 3]. See @fig:curve.\n\n"
            "![Curve](c.png){#fig:curve}\n\n## References\n\nSmith, J. (2020). Sleep and memory.\n")

    def test_passes_clean_text(self):
        self.assertEqual(vo.verify_style(self.GOOD) + vo.verify_citations(self.GOOD)
                         + vo.verify_cross_refs(self.GOOD), [])

    def test_flags_problems(self):
        bad = "It is really good; moreover it works \u2014 [Doe, 2001, p. 2]. See @tbl:none.\n"
        joined = " ".join(vo.verify_style(bad) + vo.verify_citations(bad) + vo.verify_cross_refs(bad))
        for needle in ("banned 'really'", "banned 'moreover'", "semicolon", "em dash",
                       "Orphan", "@tbl:none"):
            self.assertIn(needle, joined)

    def test_code_and_quotes_exempt(self):
        text = "Run `python x.py --sources` now.\n\n```\nusing; really\n```\nHe said \"really good; sure\".\n"
        self.assertEqual(vo.verify_style(text), [])


if __name__ == "__main__":
    unittest.main()
