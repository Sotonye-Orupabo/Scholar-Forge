#!/usr/bin/env python3
"""ScholarForge quality gate: style, citations, cross-references, overlap.

Usage:
  python verify_output.py draft.md [--sources DIR] [--prior-work DIR]
                          [--check-links] [--json] [--ngram N]
Exit code 0 = pass, 1 = findings, 2 = usage error.
"""
import json
import os
import re
import sys
import urllib.error
import urllib.request

BANNED_WORDS = [
    "very", "really", "literally", "actually", "certainly", "probably", "basically",
    "could", "maybe", "delve", "embark", "enlightening", "esteemed", "shed light",
    "craft", "crafting", "not only", "not alone", "in a world where", "revolutionize",
    "disruptive", "utilize", "using", "dive deep", "tapestry", "unravel", "harness",
    "exciting", "groundbreaking", "cutting-edge", "remarkable", "remains to be seen",
    "glimpse into", "navigating the landscape", "stark testament", "in summary",
    "in conclusion", "moreover", "boost", "skyrocketing", "opened up", "powerful",
    "ever-evolving",
]

FENCE = re.compile(r"^(```|~~~).*?^\1\s*$", re.S | re.M)
INLINE_CODE = re.compile(r"`[^`\n]*`")
FRONT_MATTER = re.compile(r"\A---\n.*?\n---\n", re.S)
QUOTED = re.compile(r"\"[^\"\n]{3,}\"|\u201c[^\u201d\n]{3,}\u201d")

CITE = re.compile(
    r"\[([A-Z][^\[\],\d]*?),\s*(\d{4})[a-z]?(?:,\s*(pp?\.\s*[\d\u2013\-]+))?\]"
)
BIB_HEADING = re.compile(r"^#{1,6}\s*(references|bibliography|works cited)\s*$", re.I | re.M)
BIB_ENTRY = re.compile(r"^\s*(?:[-*]\s+|\d+\.\s+)?([A-Z][^,(\n]*?)(?:,[^(\n]*)?\((\d{4})[a-z]?\)")
ANCHOR = re.compile(r"\{#((?:fig|tbl|eq|sec):[\w-]+)\}")
REF = re.compile(r"@((?:fig|tbl|eq|sec):[\w-]+)")
URL = re.compile(r"https?://[^\s)\]>]+|10\.\d{4,9}/[^\s)\]>]+")


def strip_code(text):
    """Remove front matter and code so style rules only see prose."""
    text = FRONT_MATTER.sub("", text)
    text = FENCE.sub("", text)
    return INLINE_CODE.sub("", text)


def line_of(text, pos):
    return text.count("\n", 0, pos) + 1


def surname(name):
    name = re.split(r"\s+(?:et al\.?|and|&)\s*", name.strip())[0]
    return name.split()[-1] if name else name


def verify_style(text):
    errors = []
    body = strip_code(text)
    for m in re.finditer(r"\u2014|(?<=\s)--(?=\s)|(?<=\w)--(?=\w)", body):
        errors.append(f"Punctuation (line {line_of(body, m.start())}): em dash or '--'.")
    scan = QUOTED.sub(lambda m: re.sub(r"[^\n]", " ", m.group()), body)  # direct quotes are exempt
    for m in re.finditer(";", scan):
        errors.append(f"Punctuation (line {line_of(scan, m.start())}): semicolon.")
    for word in BANNED_WORDS:
        for m in re.finditer(r"\b" + re.escape(word) + r"\b", scan, re.I):
            errors.append(f"Style (line {line_of(scan, m.start())}): banned '{word}'.")
    return errors


def split_bibliography(text):
    m = BIB_HEADING.search(text)
    if not m:
        return text, ""
    return text[: m.start()], text[m.end():]


def verify_citations(text):
    errors = []
    body, bib = split_bibliography(strip_code(text))
    cited = {}
    for m in CITE.finditer(body):
        key = (surname(m.group(1)), m.group(2))
        cited.setdefault(key, []).append((line_of(body, m.start()), m.group(3)))
    if not cited:
        errors.append("Citation warning: no [Author, Year, p. X] citations found.")
    for key, uses in cited.items():
        if all(page is None for _, page in uses):
            errors.append(f"Citation (line {uses[0][0]}): [{key[0]}, {key[1]}] has no page reference.")
    listed = {}
    for line in bib.splitlines():
        m = BIB_ENTRY.match(line)
        if m:
            listed[(surname(m.group(1)), m.group(2))] = line.strip()
    if cited and not listed:
        errors.append("Orphan citation: in-text citations exist but no References entries were parsed.")
        return errors
    for key in sorted(set(cited) - set(listed)):
        errors.append(f"Orphan citation: [{key[0]}, {key[1]}] has no bibliography entry.")
    for key in sorted(set(listed) - set(cited)):
        errors.append(f"Orphan reference: {key[0]} ({key[1]}) is never cited in text.")
    return errors


def verify_cross_refs(text):
    body = strip_code(text)
    anchors = set(ANCHOR.findall(body))
    errors = []
    for m in REF.finditer(body):
        if m.group(1) not in anchors:
            errors.append(f"Cross-reference (line {line_of(body, m.start())}): '@{m.group(1)}' has no anchor.")
    return errors


def ngram_set(text, n):
    words = re.findall(r"\w+", text.lower())
    return {tuple(words[i:i + n]) for i in range(len(words) - n + 1)}


def check_overlap(text, others, n=5, label="Source"):
    mine = ngram_set(strip_code(text), n)
    out = []
    for name, other in others.items():
        shared = mine & ngram_set(other, n)
        if shared:
            sample = " ".join(sorted(shared)[0])
            out.append(f"{label} overlap: {len(shared)} shared {n}-word run(s) with '{name}' "
                       f"(e.g. \"{sample}\"). Quote directly or rewrite.")
    return out


def read_dir(path):
    data = {}
    for name in sorted(os.listdir(path)):
        full = os.path.join(path, name)
        if os.path.isfile(full):
            with open(full, encoding="utf-8", errors="ignore") as fh:
                data[name] = fh.read()
    return data


def check_links(text, timeout=8):
    errors = []
    _, bib = split_bibliography(text)
    for raw in sorted(set(URL.findall(bib))):
        url = raw.rstrip(".,")
        if url.startswith("10."):
            url = "https://doi.org/" + url
        try:
            req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "ScholarForge/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                if resp.geturl().rstrip("/") != url.rstrip("/"):
                    errors.append(f"Link redirect: {url} -> {resp.geturl()}")
        except urllib.error.HTTPError as e:
            errors.append(f"Dead link ({e.code}): {url}")
        except Exception as e:  # network off, DNS failure, timeout
            errors.append(f"Link unreachable: {url} ({type(e).__name__})")
    return errors


def opt(argv, flag, default=None):
    if flag in argv:
        i = argv.index(flag)
        if i + 1 < len(argv):
            return argv[i + 1]
        print(f"{flag} needs a value", file=sys.stderr)
        sys.exit(2)
    return default


def main(argv):
    if len(argv) < 2 or argv[1].startswith("--"):
        print(__doc__)
        return 2
    with open(argv[1], encoding="utf-8") as fh:
        text = fh.read()
    n = int(opt(argv, "--ngram", 5))
    findings = verify_style(text) + verify_citations(text) + verify_cross_refs(text)
    if opt(argv, "--sources"):
        findings += check_overlap(text, read_dir(opt(argv, "--sources")), n, "Patchwriting")
    if opt(argv, "--prior-work"):
        findings += check_overlap(text, read_dir(opt(argv, "--prior-work")), n, "Self-plagiarism")
    if "--check-links" in argv:
        findings += check_links(text)
    if "--json" in argv:
        print(json.dumps({"passed": not findings, "findings": findings}, indent=2))
    elif findings:
        print("=== Quality Verification Results ===")
        for f in findings:
            print(f"- {f}")
    else:
        print("All verification checks passed.")
    return 1 if findings else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
