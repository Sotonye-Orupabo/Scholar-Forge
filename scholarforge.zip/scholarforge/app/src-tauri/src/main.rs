#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod router;

use serde::Serialize;

#[derive(Serialize)]
struct Hit {
    csl_id: String,
    page: u32,
    section: String,
    text: String,
}

#[tauri::command]
fn route_task(tier: String, online: bool, prefer_local: bool) -> Result<router::Route, String> {
    router::route(&tier, online, prefer_local)
}

/// Stub. Replace with LanceDB dense search fused with SQLite FTS5 (see prototype/scholarforge/store.py).
#[tauri::command]
fn search_sources(query: String, k: usize) -> Vec<Hit> {
    let _ = (query, k);
    vec![Hit {
        csl_id: "smith2020".into(),
        page: 14,
        section: "Results".into(),
        text: "Sleep improved recall of word lists in the treatment group.".into(),
    }]
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![route_task, search_sources])
        .run(tauri::generate_context!())
        .expect("error while running ScholarForge");
}
