//! Hybrid offline/online routing (blueprint section 1.3). Mirrors prototype/scholarforge/router.py.
use serde::Serialize;

#[derive(Debug, Serialize, PartialEq)]
pub struct Route {
    pub target: &'static str,
    pub label: &'static str,
}

pub fn route(tier: &str, online: bool, prefer_local: bool) -> Result<Route, String> {
    match tier {
        "draft" => Ok(Route { target: "local", label: "AI-DRAFT" }),
        "submission" if online && !prefer_local => Ok(Route { target: "cloud", label: "AI-DRAFT" }),
        "submission" => Ok(Route { target: "local", label: "unreviewed, offline draft" }),
        other => Err(format!("unknown tier: {other}")),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn draft_stays_local_even_online() {
        assert_eq!(route("draft", true, false).unwrap().target, "local");
    }

    #[test]
    fn submission_offline_is_labelled() {
        assert_eq!(route("submission", false, false).unwrap().label, "unreviewed, offline draft");
    }

    #[test]
    fn submission_online_goes_to_cloud() {
        assert_eq!(route("submission", true, false).unwrap().target, "cloud");
    }
}
