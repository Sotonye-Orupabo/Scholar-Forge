// Thin wrapper over Tauri commands. Falls back to mock data in a plain browser (PWA/dev).
export type Route = { target: "local" | "cloud"; label: string };
export type Hit = { csl_id: string; page: number; section: string; text: string };

const inTauri = typeof window !== "undefined" && "__TAURI_INTERNALS__" in window;

async function call<T>(cmd: string, args: Record<string, unknown>, fallback: T): Promise<T> {
  if (!inTauri) return fallback;
  const { invoke } = await import("@tauri-apps/api/core");
  return invoke<T>(cmd, args);
}

export const routeTask = (tier: "draft" | "submission", online: boolean) =>
  call<Route>("route_task", { tier, online, preferLocal: false }, {
    target: tier === "draft" || !online ? "local" : "cloud",
    label: tier === "submission" && !online ? "unreviewed, offline draft" : "AI-DRAFT",
  });

export const searchSources = (query: string) =>
  call<Hit[]>("search_sources", { query, k: 5 }, [
    { csl_id: "smith2020", page: 14, section: "Results", text: "Sleep improved recall of word lists in the treatment group." },
  ]);
