import { useEffect, useState } from "react";
import { Hit, Route, routeTask, searchSources } from "./api";

type Block = { id: number; text: string; status: "pending" | "accepted" };

export default function App() {
  const [online, setOnline] = useState(navigator.onLine);
  const [tier, setTier] = useState<"draft" | "submission">("draft");
  const [route, setRoute] = useState<Route | null>(null);
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<Hit[]>([]);
  const [blocks, setBlocks] = useState<Block[]>([]);

  useEffect(() => {
    const on = () => setOnline(true), off = () => setOnline(false);
    window.addEventListener("online", on); window.addEventListener("offline", off);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, []);
  useEffect(() => { routeTask(tier, online).then(setRoute); }, [tier, online]);

  const generate = async () => {
    const found = await searchSources(query);
    setHits(found);
    const cites = found.map((h) => `[${h.csl_id}, p. ${h.page}]`).join(" ");
    setBlocks((b) => [...b, { id: b.length + 1, status: "pending",
      text: `Draft block ${b.length + 1} for "${query}". Generation is stubbed in this scaffold. Sources: ${cites}` }]);
  };
  const accept = (id: number) => setBlocks((b) => b.map((x) => (x.id === id ? { ...x, status: "accepted" } : x)));

  return (
    <div className="shell">
      <aside className="sources" aria-label="Sources">
        <h2>Sources</h2>
        <label>
          Search your library
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="e.g. sleep and memory" />
        </label>
        <button onClick={generate} disabled={!query.trim()}>Draft a block</button>
        <ul>
          {hits.map((h, i) => (
            <li key={i}>
              <cite>{h.csl_id}, p. {h.page}</cite>
              <span className="section">{h.section}</span>
              <p>{h.text}</p>
            </li>
          ))}
        </ul>
        {hits.length === 0 && <p className="empty">No sources yet. Search to pull passages with page numbers.</p>}
      </aside>

      <main className="draft" aria-label="Draft">
        <header>
          <div className="segmented" role="group" aria-label="Task tier">
            {(["draft", "submission"] as const).map((t) => (
              <button key={t} aria-pressed={tier === t} onClick={() => setTier(t)}>
                {t === "draft" ? "Draft" : "Submission-ready"}
              </button>
            ))}
          </div>
          <p className="route">
            {online ? "Online" : "Offline"}. Running on {route?.target ?? "..."}. Output labelled <mark>{route?.label}</mark>.
          </p>
        </header>
        {blocks.length === 0 && <p className="empty">Your draft appears here one block at a time. Accept, edit, or regenerate each block.</p>}
        {blocks.map((b) => (
          <article key={b.id} className={b.status}>
            <p contentEditable suppressContentEditableWarning>{b.text}</p>
            {b.status === "pending" && (
              <div className="actions">
                <button onClick={() => accept(b.id)}>Accept block</button>
                <button className="quiet" onClick={generate}>Regenerate</button>
              </div>
            )}
          </article>
        ))}
      </main>

      <aside className="integrity" aria-label="Integrity checks">
        <h2>Integrity</h2>
        <ul className="checks">
          <li>Patchwriting: waiting for a block</li>
          <li>Self-reuse: waiting for a block</li>
          <li>Orphan citations: none found</li>
          <li>Dead links: checked when online</li>
        </ul>
      </aside>
    </div>
  );
}
