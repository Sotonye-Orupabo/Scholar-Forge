
Role & Objective

Act as a Lead AI Systems Architect, Full-Stack Engineer, and Academic Writing Specialist. Your task is to design, specify, and write the full technical architecture for ScholarForge AI, a cross-platform (Desktop and Mobile) academic research app. The app enables users to write research papers, theses, or dissertations using local documents or linked cloud folders (e.g., Google Drive), operating completely offline when necessary and drawing on web search when online.
ScholarForge AI is a cross-platform (Desktop and Mobile) academic research application. The system enables users to write research papers, theses, or dissertations with local documents or linked cloud folders (e.g., Google Drive), operating offline when necessary and searching the web when online.
All academic outputs and application specifications follow David Evans et al.'s How to Write a Better Thesis (Springer) and enforce strict writing style constraints. Academic-integrity safeguards, genuine synthesis, correct attribution, compliance reporting, and submission formatting sit alongside style constraints as first-class requirements.
1. End-to-End Technical Architecture
1.1 Multi-Platform Deployment Stack
 * Desktop Application: Built with Tauri (Rust core + React/TypeScript frontend). Rust manages file system operations, local vector database instances, and native process lifecycle, for minimal memory overhead and fast execution.
 * Mobile & Web Access: Built as a Progressive Web App (PWA) with Web Workers for background caching and IndexedDB for local storage, synchronizing with the desktop instance or direct cloud sources when online.
1.2 Storage & Local Vector Database
 * Vector Engine: Embedded LanceDB running natively in Rust (Desktop) or compiled to WebAssembly (PWA/Mobile).
 * Embedding Model: nomic-embed-text running locally via WebGPU/ONNX Runtime, or bge-small-en-v1.5 for a lighter, faster 384-dimensional dense vector.
 * Document Database: SQLite (via rusqlite) tracking metadata, citation relationships, draft history trees, and full-text search indexes.
1.3 Hybrid Offline/Online LLM Orchestration
 * Offline Processing: Local inference via GGML/GGUF models (e.g., Llama-3-8B quantized) with llama.cpp bindings in Rust. Scoped to retrieval, outlining, note synthesis, and first-draft scaffolding.
 * Online Processing: Remote API routing to larger, non-quantized cloud LLMs, supplemented by direct Tavily or SerpAPI integration for academic web searching. Handles final chapter prose and anything the user marks submission-ready.
 * Router Logic: Weighs network status, user preference, and task tier (draft vs. submission-ready). Draft-tier work routes to the local model regardless of connectivity. Submission-tier work routes online when reachable; offline, the system still drafts locally but labels the output "unreviewed, offline draft" until it clears an online or human pass.
2. Drive Sync & PDF Processing Pipeline
2.1 Ingestion Logic
 * Cloud Sync: Users supply an authenticated or public folder link. The background daemon polls folder metadata, checks hash signatures against SQLite records, downloads new or modified PDFs, and stores them in the local cache directory.
 * Direct Upload: Files dropped into the UI are copied to the application cache immediately.
 * Parsing: The parser extracts structural layout, identifying section titles, paragraphs, tables, figure captions, and page boundaries by exact PDF byte offsets.
 * Chunking: Text is split into 300 to 500-word blocks. Each block retains source document metadata, section headers, and target page numbers.
 * Indexing: Embeddings are calculated for each chunk and appended to the local LanceDB vector table.
3. Synthesis, Attribution & Citation Integrity Engine
3.1 Synthesis & Paraphrase Integrity
 * Conceptual Abstraction: Retrieved chunks are reduced to their underlying claim, method, or finding before prose generates.
 * Cross-Source Integration: Generation synthesizes across multiple sources, comparing and building claims rather than restating one source at a time.
 * Fact Retention Verification: Checks extracted numerical claims, entity names, and logical assertions against original chunks.
 * Overlap & Patchwriting Check: Generated text is compared against source chunks for shared 5-word (or longer) runs and matching sentence order. Overlaps route back to the user to either quote directly or rewrite manually.
3.2 Self-Plagiarism Verification Engine
 * Local Prior-Work Index: The system indexes the user’s previously submitted manuscripts, term papers, and earlier thesis chapters stored in SQLite/LanceDB.
 * Reuse Detection: Compares new generated or edited prose against the local prior-work index.
 * Alerting: Flags duplicate logic or prose from the author's own library, requiring proper self-citation (e.g., "As argued in Okpara [2025]...") to avoid institutional self-plagiarism violations.
3.3 Dynamic CSL Citation & Orphan-Citation Engine
 * Citation Parsing: Parses BibTeX, RIS, or inline metadata to construct complete CSL JSON records.
 * Formatting Engine: Embedded CSL engine formats references dynamically across styles (APA 7th, IEEE, Harvard, Chicago 17th, MLA 9th, Vancouver).
 * In-Text Mapping: Every generated claim links directly to its source database ID and explicit page reference ([Author, Year, p. X]).
 * Orphan & Link Verification:
   * Bidirectional Map: Ensures every in-text citation has a corresponding CSL bibliography entry and every bibliography entry is cited at least once in the manuscript.
   * Dead DOI/URL Auditor: When online, asynchronously verifies HTTP status codes for DOIs and web links in the bibliography, flagging 404s, redirected links, or broken handles.
3.4 Automated AI-Disclosure Statement Generator
 * Provenance Tracking: The system logs every LLM interaction, tracking generated ranges, prompt inputs, model names, and active [AI-DRAFT] tags.
 * Disclosure Appendix Compilation: Generates a standard compliance appendix detailing tool use, prompt intent, and human edit ratios.
 * Institutional Presets: Formats declarations to meet specific institutional standards (e.g., University of Saskatchewan, Oxford, Princeton, Imperial College London).
4. Long-Form Chapter & Document Management
4.1 Sequenced Generation & Human Checkpoint
 * Outline Generation: Builds a structured outline based on Evans et al.'s thesis framework.
 * Block Allocation: Each section receives a target word count (e.g., 2,000 words per turn).
 * Context Anchor Tracking: Each turn takes in the last 500 words of the previous response, the target section outline, and retrieved source chunks.
 * Human Checkpoint: Generation pauses after each block for the user to accept, edit, or regenerate.
4.2 Draft Versioning & Rollback History
 * Immutable State Log: Every accept/edit/regenerate event writes a delta snapshot to SQLite.
 * Branching & Rollback: Allows authors to restore earlier draft states or compare diffs across generation iterations without losing manually written prose.
4.3 Figure, Table & Equation Cross-Reference Engine
 * Anchor Registration: Automatically assigns unified identifiers to visual and mathematical assets (@fig:method_diagram, @tbl:sample_demographics, @eq:regression_model).
 * Dynamic Renumbering: Automatically updates numbering and in-text cross-references (e.g., "see Figure 3.1") whenever figures, tables, or sections are moved, added, or deleted.
5. Submission-Ready Export Pipeline
5.1 Document Formatting & Compilation Engine
To bridge the gap between ingestion and final submission, ScholarForge AI implements a native export pipeline powered by Pandoc, Typst, and LaTeX (Tectonic/XeLaTeX).
 * Template Engine: Supports custom institutional style sheets (.typ, .tex, or .docx) setting explicit margins (e.g., 1.5-inch binding margin), line spacing (double/1.5), font families (Times New Roman, Computer Modern, Arial), running headers, and page numbering (roman numerals for front matter, arabic for body).
 * Automated Structure Generation:
 * Title Page: Formatted according to institutional guidelines.
 * Front Matter: Automated generation of Abstract, Dedication, Acknowledgments, Table of Contents (TOC), List of Figures (LOF), and List of Tables (LOT).
 * Body & Appendices: Automatically appends the AI-Disclosure Statement (Section 3.4) and CSL Bibliography.
 * Format Targets: Single-click compile to submission-ready PDF, editable Microsoft Word (.docx), or publication-ready LaTeX zip archives.
6. Privacy, Security & Data Handling Guardrails
6.1 Telemetry & Data Flow Transparency
 * Local-First Processing: Document parsing, vector indexing, local drafting, and citation checks run 100% locally on-device.
 * Online Mode Data Bounds:
   * When online cloud LLMs or web searches are invoked, only the active prompt, sanitized source snippets, and active target section text leave the local device.
   * User credentials, private local PDFs not cited in the query, and offline draft histories are never transmitted.
 * Zero-Retention Guarantee: Online API calls enforce zero-data-retention headers, ensuring private research and unfiled thesis chapters are not retained for external model training.
7. Automated Quality Verification Script
Save the following as verify_output.py. It verifies style constraints, banned vocabulary, source overlap, orphan citations, cross-references, and self-plagiarism.
import re
import sys
import os
import urllib.request
import urllib.error

BANNED_WORDS = [
    "very", "really", "literally", "actually", "certainly", "probably", "basically",
    "could", "maybe", "delve", "embark", "enlightening", "esteemed", "shed light",
    "craft", "crafting", "not only", "not alone", "in a world where", "revolutionize",
    "disruptive", "utilize", "using", "dive deep", "tapestry", "unravel", "harness",
    "exciting", "groundbreaking", "cutting-edge", "remarkable", "remains to be seen",
    "glimpse into", "navigating the landscape", "stark testament", "in summary",
    "in conclusion", "moreover", "boost", "skyrocketing", "opened up", "powerful",
    "ever-evolving"
]

def verify_style_and_punct(text):
    errors = []
    if "—" in text or "--" in text:
        errors.append("Punctuation Error: Em dash ('—' or '--') detected.")
    if ";" in text:
        errors.append("Punctuation Error: Semicolon (';') detected.")

    for word in BANNED_WORDS:
        pattern = r"\b" + re.escape(word) + r"\b"
        matches = re.findall(pattern, text, flags=re.IGNORECASE)
        if matches:
            errors.append(f"Style Error: Banned word/phrase found: '{word}' ({len(matches)} instance(s))")

    return errors

def verify_citations_and_orphans(text):
    errors = []
    # Match in-text citations: [Author, Year, p. X] or [Author, Year]
    in_text_citations = set(re.findall(r"\[([A-Za-z]+),\s*(\d{4})(?:,\s*p\.\s*\d+)?\]", text))
    
    # Match Bibliography entries: e.g., Author (Year)
    bib_entries = set(re.findall(r"^([A-Za-z]+)\s*\((\d{4})\)", text, re.MULTILINE))

    if not in_text_citations:
        errors.append("Citation Warning: No exact page citations matching '[Author, Year, p. X]' were detected.")

    # Check for Orphan In-Text Citations (Cited but missing in Bib)
    if bib_entries:
        for cite in in_text_citations:
            if cite not in bib_entries:
                errors.append(f"Orphan Citation Error: In-text citation [{cite[0]}, {cite[1]}] has no bibliography entry.")

        # Check for Uncited Bibliography Entries
        for bib in bib_entries:
            if bib not in in_text_citations:
                errors.append(f"Orphan Bibliography Error: Reference '{bib[0]} ({bib[1]})' is listed in bibliography but never cited in-text.")

    return errors

def verify_cross_references(text):
    errors = []
    # Identify defined anchors like @fig:label, @tbl:label
    anchors = set(re.findall(r"\{\#(fig:[\w-]+|tbl:[\w-]+|eq:[\w-]+)\}", text))
    # Identify citations to anchors like @fig:label
    refs = set(re.findall(r"@(fig:[\w-]+|tbl:[\w-]+|eq:[\w-]+)\b", text))

    for ref in refs:
        if ref not in anchors:
            errors.append(f"Cross-Reference Error: Broken reference '@{ref}' (anchor missing in text).")

    return errors

def check_overlap(generated_text, comparison_texts, n=5, label_prefix="Source"):
    def ngrams(text):
        words = re.findall(r"\b\w+\b", text.lower())
        return set(tuple(words[i:i + n]) for i in range(len(words) - n + 1))

    gen_ngrams = ngrams(generated_text)
    flags = []
    for label, comp_text in comparison_texts.items():
        overlap = gen_ngrams & ngrams(comp_text)
        if overlap:
            sample = " ".join(next(iter(overlap)))
            flags.append(
                f"{label_prefix} Overlap Warning: {len(overlap)} shared {n}-word run(s) with '{label}' "
                f"(e.g. \"{sample}\"). Rewrite or quote directly."
            )
    return flags

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python verify_output.py <path_to_markdown_file> [--sources <dir>] [--prior-work <dir>]")
        sys.exit(1)

    file_path = sys.argv[1]
    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read()

    print("=== Quality Verification Results ===")
    all_errors = []

    # 1. Style & Punctuation
    all_errors.extend(verify_style_and_punct(text))

    # 2. Orphan Citations
    all_errors.extend(verify_citations_and_orphans(text))

    # 3. Cross-References
    all_errors.extend(verify_cross_references(text))

    # 4. Source Overlap Check
    if "--sources" in sys.argv:
        idx = sys.argv.index("--sources")
        sources_dir = sys.argv[idx + 1]
        source_texts = {}
        for fname in os.listdir(sources_dir):
            fpath = os.path.join(sources_dir, fname)
            if os.path.isfile(fpath):
                with open(fpath, "r", encoding="utf-8", errors="ignore") as sf:
                    source_texts[fname] = sf.read()
        all_errors.extend(check_overlap(text, source_texts, label_prefix="Source Patchwriting"))

    # 5. Self-Plagiarism Check
    if "--prior-work" in sys.argv:
        idx = sys.argv.index("--prior-work")
        pw_dir = sys.argv[idx + 1]
        pw_texts = {}
        for fname in os.listdir(pw_dir):
            fpath = os.path.join(pw_dir, fname)
            if os.path.isfile(fpath):
                with open(fpath, "r", encoding="utf-8", errors="ignore") as pf:
                    pw_texts[fname] = pf.read()
        all_errors.extend(check_overlap(text, pw_texts, label_prefix="Self-Plagiarism"))

    if not all_errors:
        print("All verification checks passed successfully.")
        sys.exit(0)
    else:
        for err in all_errors:
            print(f"- {err}")
        sys.exit(1)

